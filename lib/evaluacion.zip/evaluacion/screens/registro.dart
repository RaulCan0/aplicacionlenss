import 'package:aplicacionlensys/colores_app.dart';
import 'package:aplicacionlensys/evaluacion/models/empresa.dart';
import 'package:aplicacionlensys/evaluacion/providers/evaluaciones_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

class Registro extends ConsumerWidget {
  const Registro({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
  final empresas = ref.watch(evaluacionProvider.select((s) => s.empresas));
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Coloresapp.lensys,
        centerTitle: true,
        title: const Text(
          'Diagnóstico Lean TrainningCenter',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
      ),
      endDrawer: Drawer(
        child: Container(), // Menú vacío por ahora
      ),
      body: empresas.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  const Text('Aún no hay empresas registradas'),
                ],
              ),
            )
          : ListView.builder(
              itemCount: empresas.length,
              itemBuilder: (context, index) {
                final empresa = empresas[index];
                return Card(
                  child: ListTile(
                    title: Text(empresa.nombre),
                    onTap: () {
                      // Aquí podrías navegar a DimensionScreen y pasar el uuid y nombre
                      // final uuid = Uuid().v4();
                      // Navigator.push(...)
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Coloresapp.lensys,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () {
          showDialog(
            context: context,
            builder: (ctx) {
              final nombreController = TextEditingController();
              return AlertDialog(
                title: const Text('Registrar Empresa'),
                content: TextField(
                  controller: nombreController,
                  decoration: const InputDecoration(hintText: 'Nombre de la empresa'),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: const Text('Cancelar'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      final nombre = nombreController.text.trim();
                      if (nombre.isNotEmpty) {
                        ref.read(evaluacionProvider.notifier).agregarEmpresa(
                          Empresa(id: const Uuid().v4(), nombre: nombre),
                        );
                        Navigator.of(ctx).pop();
                      }
                    },
                    child: const Text('Registrar'),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}