import 'package:aplicacionlensys/evaluacion/providers/evaluaciones_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/empresa.dart';
import '../models/asociado_evaluacion.dart';
import '../models/calificacion.dart';
import 'supabase_service.dart';

final evaluacionProvider =
    StateNotifierProvider<EvaluacionController, EvaluacionState>((ref) {
  return EvaluacionController();
});

final supabaseServiceProvider = Provider((ref) => SupabaseService());

class EvaluacionRepository {
  final SupabaseService _service;
  final EvaluacionController _controller;

  EvaluacionRepository(this._service, this._controller);

  Future<void> crearEmpresa(Empresa empresa) async {
    await _service.crearEmpresa(empresa.toMap());
    _controller.agregarEmpresa(empresa);
  }

  Future<void> actualizarEmpresa(Empresa empresa) async {
    await _service.editarEmpresa(empresa.id, empresa.toMap());
    _controller.actualizarEmpresa(empresa);
  }

  Future<void> eliminarEmpresa(Empresa empresa) async {
    await _service.eliminarEmpresa(empresa.id);
    _controller.eliminarEmpresa(empresa.id);
  }

  Future<void> crearAsociado(AsociadoEvaluacion asociado) async {
    await _service.crearAsociado(asociado.toMap());
    _controller.agregarAsociadoEvaluacion(asociado);
  }

  Future<void> actualizarAsociado(AsociadoEvaluacion asociado) async {
    await _service.editarAsociado(asociado.id, asociado.toMap());
    _controller.editarAsociadoEvaluacion(asociado);
  }

  Future<void> eliminarAsociado(AsociadoEvaluacion asociado) async {
    await _service.eliminarAsociado(asociado.id);
    _controller.eliminarAsociadoEvaluacion(asociado.id);
  }

  Future<void> crearCalificacion(Calificacion calificacion) async {
    await _service.crearCalificacion(calificacion.toMap());
    _controller.registrarCalificacion(calificacion);
  }

  Future<void> actualizarCalificacion(Calificacion calificacion) async {
    await _service.editarCalificacion(calificacion.id, calificacion.toMap());
    _controller.editarCalificacionPorId(calificacion.id, calificacion);
  }

  Future<void> eliminarCalificacion(Calificacion calificacion) async {
    await _service.eliminarCalificacion(calificacion.id);
    _controller.eliminarCalificacion(calificacion.id);
  }
}

final evaluacionRepositoryProvider = Provider<EvaluacionRepository>((ref) {
  final service = ref.watch(supabaseServiceProvider);
  final controller = ref.watch(evaluacionProvider.notifier);
  return EvaluacionRepository(service, controller);
});
