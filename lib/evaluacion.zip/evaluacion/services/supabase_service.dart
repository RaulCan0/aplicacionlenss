import 'package:aplicacionlensys/evaluacion/models/calificacion.dart';
import 'package:supabase_flutter/supabase_flutter.dart';


class SupabaseService {
  // Obtener todas las calificaciones de una evaluación
  Future<List<Calificacion>> getCalificacionesPorEvaluacion(String evaluacionId) async {
    final response = await _client
        .from('calificaciones')
        .select()
        .eq('evaluacionId', evaluacionId)
        .execute();
    final data = response.data as List<dynamic>? ?? [];
    return data.map((e) => Calificacion.fromMap(e as Map<String, dynamic>)).toList();
  }
  // Obtener asociados de una evaluación
  Future<List<dynamic>> getAsociadosEvaluacion(String evaluacionId) async {
    final response = await _client
        .from('asociados_evaluacion')
        .select()
        .eq('evaluacionId', evaluacionId)
        .execute();
    return response.data as List<dynamic>? ?? [];
  }

  // Obtener calificaciones de una evaluación
  Future<List<dynamic>> getCalificacionesEvaluacion(String evaluacionId) async {
    final response = await _client
        .from('calificaciones')
        .select()
        .eq('evaluacionId', evaluacionId)
        .execute();
    return response.data as List<dynamic>? ?? [];
  }

  // Upsert promedio por principio
  Future<void> upsertPromedioPrincipio({
    required String evaluacionId,
    required String dimensionId,
    required String principioId,
    required String cargo,
    required double promedio,
  }) async {
    await _client.from('promedios_principio').upsert({
      'evaluacionId': evaluacionId,
      'dimensionId': dimensionId,
      'principioId': principioId,
      'cargo': cargo,
      'promedio': promedio,
    }).execute();
  }

  // Upsert promedio por comportamiento
  Future<void> upsertPromedioComportamiento({
    required String evaluacionId,
    required String dimensionId,
    required String comportamientoId,
    required String cargo,
    required double promedio,
  }) async {
    await _client.from('promedios_comportamiento').upsert({
      'evaluacionId': evaluacionId,
      'dimensionId': dimensionId,
      'comportamientoId': comportamientoId,
      'cargo': cargo,
      'promedio': promedio,
    }).execute();
  }

  // Upsert promedio por dimensión
  Future<void> upsertPromedioDimension({
    required String evaluacionId,
    required String dimensionId,
    required String cargo,
    required double promedio,
  }) async {
    await _client.from('promedios_dimension').upsert({
      'evaluacionId': evaluacionId,
      'dimensionId': dimensionId,
      'cargo': cargo,
      'promedio': promedio,
    }).execute();
  }
  static final SupabaseService _instance = SupabaseService._internal();
  final SupabaseClient _client = Supabase.instance.client;

  factory SupabaseService() => _instance;
  SupabaseService._internal();

  // ---------------- EMPRESAS ----------------
  Future<void> crearEmpresa(Map<String, dynamic> data) async {
    await _client.from('empresas').insert(data).execute();
  }
  Future<void> editarEmpresa(String id, Map<String, dynamic> data) async {
    await _client.from('empresas').update(data).eq('id', id).execute();
  }
  Future<void> eliminarEmpresa(String id) async {
    await _client.from('empresas').delete().eq('id', id).execute();
  }

  // ---------------- ASOCIADOS ----------------
  Future<void> crearAsociado(Map<String, dynamic> data) async {
    await _client.from('asociados_evaluacion').insert(data).execute();
  }
  Future<void> editarAsociado(String id, Map<String, dynamic> data) async {
    await _client.from('asociados_evaluacion').update(data).eq('id', id).execute();
  }
  Future<void> eliminarAsociado(String id) async {
    await _client.from('asociados_evaluacion').delete().eq('id', id).execute();
  }

  // ---------------- CALIFICACIONES ----------------
  Future<void> crearCalificacion(Map<String, dynamic> data) async {
    await _client.from('calificaciones').insert(data).execute();
  }
  Future<void> editarCalificacion(String id, Map<String, dynamic> data) async {
    await _client.from('calificaciones').update(data).eq('id', id).execute();
  }
  Future<void> eliminarCalificacion(String id) async {
    await _client.from('calificaciones').delete().eq('id', id).execute();
  }

  Future<List<Calificacion>> obtenerCalificacionesPorAsociadoEvaluacion({
    required String evaluacionId,
    required String asociadoEvaluacionId,
  }) async {
    final response = await _client
        .from('calificaciones')
        .select()
        .eq('evaluacionId', evaluacionId)
        .eq('asociadoEvaluacionId', asociadoEvaluacionId)
        .execute();
    final data = response.data as List<dynamic>? ?? [];
    return data.map((e) => Calificacion.fromMap(e as Map<String, dynamic>)).toList();
  }

  // ---------------- SISTEMAS ASOCIADOS ----------------
  Future<void> crearSistema(Map<String, dynamic> data) async {
    await _client.from('sistemas_asociados').insert(data).execute();
  }
  Future<void> editarSistema(String id, Map<String, dynamic> data) async {
    await _client.from('sistemas_asociados').update(data).eq('id', id).execute();
  }
  Future<void> eliminarSistema(String id) async {
    await _client.from('sistemas_asociados').delete().eq('id', id).execute();
  }
}