enum Cargo {
  ejecutiso,
  gerente,
  miembroEquipo,
}