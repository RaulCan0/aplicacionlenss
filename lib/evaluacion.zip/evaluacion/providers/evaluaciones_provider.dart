import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/empresa.dart';
import '../models/evaluacion.dart';
import '../models/asociado_evaluacion.dart';
import '../models/calificacion.dart';

/// ======================= STATE =======================

@immutable
class EvaluacionState {
  final List<Empresa> empresas;
  final List<Evaluacion> evaluaciones;
  final List<AsociadoEvaluacion> asociados;
  final List<Calificacion> calificaciones;
  final Map<String, Set<String>> principiosEvaluados;

  const EvaluacionState({
    this.empresas = const [],
    this.evaluaciones = const [],
    this.asociados = const [],
    this.calificaciones = const [],
    this.principiosEvaluados = const {},
  });

  EvaluacionState copyWith({
    List<Empresa>? empresas,
    List<Evaluacion>? evaluaciones,
    List<AsociadoEvaluacion>? asociados,
    List<Calificacion>? calificaciones,
    Map<String, Set<String>>? principiosEvaluados,
  }) {
    return EvaluacionState(
      empresas: empresas ?? this.empresas,
      evaluaciones: evaluaciones ?? this.evaluaciones,
      asociados: asociados ?? this.asociados,
      calificaciones: calificaciones ?? this.calificaciones,
      principiosEvaluados: principiosEvaluados ?? this.principiosEvaluados,
    );
  }
}

/// =================== CONTROLLER ======================

class EvaluacionController extends StateNotifier<EvaluacionState> {
  EvaluacionController() : super(const EvaluacionState());

  void cargarEmpresas(List<Empresa> empresas) {
    state = state.copyWith(empresas: List.unmodifiable(empresas));
  }

  void agregarEmpresa(Empresa empresa) {
    final next = [...state.empresas, empresa];
    state = state.copyWith(empresas: List.unmodifiable(next));
  }

  void actualizarEmpresa(Empresa empresa) {
    final next = state.empresas.map((e) => e.id == empresa.id ? empresa : e).toList();
    state = state.copyWith(empresas: List.unmodifiable(next));
  }

  void eliminarEmpresa(String empresaId) {
    final empresas = state.empresas.where((e) => e.id != empresaId).toList();
    final evalIds = state.evaluaciones.where((e) => e.empresaId == empresaId).map((e) => e.id).toSet();
    final evaluaciones = state.evaluaciones.where((e) => e.empresaId != empresaId).toList();
    final asociados = state.asociados.where((a) => !evalIds.contains(a.evaluacionId)).toList();
    final calificaciones = state.calificaciones.where((c) => !evalIds.contains(c.evaluacionId)).toList();
    final principiosEvaluados = Map<String, Set<String>>.from(state.principiosEvaluados)
      ..removeWhere((k, _) => evalIds.contains(k));

    state = state.copyWith(
      empresas: List.unmodifiable(empresas),
      evaluaciones: List.unmodifiable(evaluaciones),
      asociados: List.unmodifiable(asociados),
      calificaciones: List.unmodifiable(calificaciones),
      principiosEvaluados: principiosEvaluados,
    );
  }

  void cargarAsociados(List<AsociadoEvaluacion> list) {
    state = state.copyWith(asociados: List.unmodifiable(list));
  }

  void agregarAsociadoEvaluacion(AsociadoEvaluacion asociado) {
    final next = [...state.asociados, asociado];
    state = state.copyWith(asociados: List.unmodifiable(next));
  }

  bool editarAsociadoEvaluacion(AsociadoEvaluacion asociadoEditado) {
    final i = state.asociados.indexWhere((a) => a.id == asociadoEditado.id);
    if (i == -1) return false;
    final next = [...state.asociados]..[i] = asociadoEditado;
    state = state.copyWith(asociados: List.unmodifiable(next));
    return true;
  }

  void eliminarAsociadoEvaluacion(String asociadoId) {
    final asociados = state.asociados.where((a) => a.id != asociadoId).toList();
    final calificaciones = state.calificaciones.where((c) => c.asociadoId != asociadoId).toList();
    state = state.copyWith(
      asociados: List.unmodifiable(asociados),
      calificaciones: List.unmodifiable(calificaciones),
    );
  }

  void cargarCalificaciones(List<Calificacion> list) {
    state = state.copyWith(calificaciones: List.unmodifiable(list));
  }

  void registrarCalificacion(Calificacion nueva) {
    final i = state.calificaciones.indexWhere((c) => c.id == nueva.id);
    if (i != -1) {
      final next = [...state.calificaciones]..[i] = nueva;
      state = state.copyWith(calificaciones: List.unmodifiable(next));
    } else {
      final next = [...state.calificaciones, nueva];
      state = state.copyWith(calificaciones: List.unmodifiable(next));
    }
  }

  bool editarCalificacionPorId(String calificacionId, Calificacion calificacionActualizada) {
    final i = state.calificaciones.indexWhere((c) => c.id == calificacionId);
    if (i == -1) return false;
    final next = [...state.calificaciones]..[i] = calificacionActualizada;
    state = state.copyWith(calificaciones: List.unmodifiable(next));
    return true;
  }

  void eliminarCalificacion(String calificacionId) {
    final next = state.calificaciones.where((c) => c.id != calificacionId).toList();
    state = state.copyWith(calificaciones: List.unmodifiable(next));
  }
}

/// =================== PROVIDER ========================

final evaluacionProvider =
    StateNotifierProvider<EvaluacionController, EvaluacionState>((ref) {
  return EvaluacionController();
});
